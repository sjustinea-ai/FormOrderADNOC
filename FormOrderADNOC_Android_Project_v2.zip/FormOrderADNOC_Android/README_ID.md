# Form Order ADNOC - APK Android

Project Android untuk aplikasi Form Order ADNOC. Aplikasi berjalan offline dan menyimpan data rekap pada HP masing-masing.

## Cara paling mudah membuat APK tanpa Android Studio
1. Buat akun/login GitHub.
2. Buat repository baru, misalnya `FormOrderADNOC`.
3. Upload seluruh isi folder project ini ke repository tersebut.
4. Buka tab **Actions**.
5. Pilih workflow **Build Form Order ADNOC APK**.
6. Tekan **Run workflow**.
7. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
8. Download `FormOrderADNOC-debug-apk.zip`.
9. Ekstrak ZIP tersebut dan ambil `app-debug.apk`.
10. Kirim APK ke HP dan install. Jika Android meminta izin, aktifkan instalasi dari sumber tersebut.

## Catatan
- Tidak memakai database pusat.
- Rekap order tersimpan di HP masing-masing melalui localStorage.
- Produk dan database bengkel sudah tertanam di aplikasi.
- APK debug ini cocok untuk pemakaian pribadi/internal. Untuk distribusi publik, gunakan APK release yang ditandatangani.
